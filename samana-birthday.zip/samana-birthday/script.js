/* =========================================================
   SAMANA — A LITTLE UNIVERSE OF MEMORIES
   ✏️  EDIT EVERYTHING PERSONAL IN THE "CONTENT" BLOCK BELOW.
   ========================================================= */
const CONTENT = {
  // Put photos in assets/images/ named exactly like these (or change the names). 5–10 photos.
  photos: [
    { src: "assets/images/photo1.jpg",  caption: "The day we met" },
    { src: "assets/images/photo2.jpg",  caption: "Our funniest trip" },
    { src: "assets/images/photo3.jpg",  caption: "That unforgettable laugh" },
    { src: "assets/images/photo4.jpg",  caption: "Just us being us" },
    { src: "assets/images/photo5.jpg",  caption: "Best day ever" },
    { src: "assets/images/photo6.jpg",  caption: "Caption goes here" }
  ],
  music: "assets/music/music.mp3",            // replace this file with your own song
  whatsapp: "923244112331",   // wishes open WhatsApp to this number (country code, no + or 0)
  usCards: [
    { title: "Our Funniest Moments", text: "Write about the time we laughed until we couldn't breathe." },
    { title: "Her Weirdest Habits",  text: "Describe her most iconic, slightly strange habit here." },
    { title: "Things That Always Make Us Laugh", text: "That one thing that never fails to crack us up." },
    { title: "Our Inside Jokes", text: "Add the joke only the two of you will ever understand." },
    { title: "Little Things That Make Her Special", text: "The tiny details only a best friend notices." }
  ],
  reasons: [
    "Your beautiful heart.", "Your crazy personality.", "Your unforgettable smile.",
    "The way you make ordinary moments special.", "You listen when it matters.",
    "Your laugh is contagious.", "You're loyal in the best way.",
    "You make everything more fun.", "You believe in me.", "Because you are simply, wonderfully you."
  ],
  letter: "Dear Samana,\n\nWrite your personal birthday letter here. Tell her what she means to you, the memories you treasure, and what you wish for her this year.\n\nWith all my love,\nYour best friend",
  // answer = index of the correct option (or your funny "official" answer)
  quiz: [
    { q: "Who is more dramatic?", options: ["Me", "You", "Both, obviously"], answer: 2 },
    { q: "Who laughs at the weirdest things?", options: ["Me", "You", "Both of us"], answer: 1 },
    { q: "Who would start an argument over nothing?", options: ["Me", "You", "We argue about who started it"], answer: 0 },
    { q: "Who is crazier?", options: ["Me", "You", "We're a matching set"], answer: 2 },
    { q: "Who is the better friend?", options: ["Me", "You", "Impossible to choose"], answer: 2 }
  ],
  // messages by score (0–5)
  quizResults: [
    "0/5 — Who ARE you? Time for a full friendship reboot.",
    "1/5 — We need to talk. Immediately.",
    "2/5 — Not bad, but I'm a little offended.",
    "3/5 — Solid. You know me better than most.",
    "4/5 — Almost perfect. Almost.",
    "5/5 — Of course. You are my person."
  ],
  finalMessage: "No matter how many birthdays pass, I hope life always gives you reasons to smile. Thank you for being my person. Here's to a lifetime of laughter, memories, and beautiful moments together."
};

/* ---------------- helpers ---------------- */
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const el = (t, c, h) => { const e = document.createElement(t); if (c) e.className = c; if (h) e.innerHTML = h; return e; };
const esc = s => s.replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------------- sound (synth blips, no files needed) ---------------- */
let actx;
const getCtx = () => { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); if (actx.state === "suspended") actx.resume(); return actx; };
function blip(f = 660, d = .15, v = .05) {
  try {
    getCtx();
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = "sine"; o.frequency.value = f; g.gain.setValueAtTime(v, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(.0001, actx.currentTime + d);
    o.connect(g).connect(actx.destination); o.start(); o.stop(actx.currentTime + d);
  } catch (e) {}
}
const chime = () => [660, 880, 1320].forEach((f, i) => setTimeout(() => blip(f, .4), i * 90));

/* ---------------- music ---------------- */
const audio = new Audio(CONTENT.music); audio.loop = true; audio.volume = .4;
/* ---------------- built-in soft romantic music (used when assets/music/music.mp3 is missing) ---------------- */
const Synth = {
  on: false,
  start() {
    if (this.on) return; this.on = true; const c = getCtx();
    this.out = c.createGain(); this.out.gain.setValueAtTime(0, c.currentTime); this.out.gain.linearRampToValueAtTime(.25, c.currentTime + 2);
    const lp = c.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 2600;
    const rv = c.createConvolver(), len = c.sampleRate * 3, ir = c.createBuffer(2, len, c.sampleRate);
    for (let k = 0; k < 2; k++) { const d = ir.getChannelData(k); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.5); }
    rv.buffer = ir; const wet = c.createGain(); wet.gain.value = .5;
    this.in = c.createGain(); this.in.connect(lp); lp.connect(this.out); lp.connect(rv); rv.connect(wet); wet.connect(this.out); this.out.connect(c.destination);
    this.nt = c.currentTime + .1; this.bar = 0; this.timer = setInterval(() => this.sched(), 250); this.sched();
  },
  stop() {
    if (!this.on) return; this.on = false; clearInterval(this.timer); const o = this.out, t = actx.currentTime;
    o.gain.cancelScheduledValues(t); o.gain.setValueAtTime(o.gain.value, t); o.gain.linearRampToValueAtTime(0, t + .8); setTimeout(() => o.disconnect(), 1000);
  },
  note(n, t, d, type, v, a) {
    const c = actx, o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.value = 440 * 2 ** ((n - 69) / 12);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + a); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    o.connect(g); g.connect(this.in); o.start(t); o.stop(t + d + .05);
  },
  sched() {
    const C = [[48, 55, 59, 64], [45, 55, 60, 64], [41, 57, 60, 64], [43, 55, 59, 62]], beat = .42;
    while (this.on && this.nt < actx.currentTime + 1) {
      const ch = C[this.bar % 4], t = this.nt;
      ch.forEach(n => this.note(n, t, beat * 8 + .8, "triangle", .06, .9));
      const s = [ch[1], ch[2], ch[3], ch[2] + 12, ch[3], ch[2], ch[1] + 12, ch[3]].map(n => n + 12);
      s.forEach((n, i) => { this.note(n, t + i * beat, 1.5, "sine", .09, .01); this.note(n + 12, t + i * beat, .6, "sine", .02, .01); });
      this.nt += beat * 8; this.bar++;
    }
  }
};
// Music always stays on once started (starts only after the first tap, never before).
audio.onerror = () => Synth.start();
function startMusic() { audio.play().catch(() => Synth.start()); }

/* ---------------- background particles (petals, hearts, pearls) ---------------- */
const bg = $("#bg"), bx = bg.getContext("2d"); let W, H, parts = [];
function size() { const d = Math.min(devicePixelRatio || 1, 2); [bg, fx].forEach(c => { c.width = innerWidth * d; c.height = innerHeight * d; }); bx.setTransform(d, 0, 0, d, 0, 0); fxc.setTransform(d, 0, 0, d, 0, 0); W = innerWidth; H = innerHeight; }
const fx = $("#fx"), fxc = fx.getContext("2d");
function mk(y) { return { x: Math.random() * W, y: y ?? Math.random() * H, s: 5 + Math.random() * 9, v: .25 + Math.random() * .6, w: Math.random() * 6, k: ["petal", "heart", "pearl"][Math.random() * 3 | 0], r: Math.random() * 6 }; }
function drawHeart(c, s) { c.beginPath(); c.moveTo(0, s * .3); c.bezierCurveTo(-s, -s * .4, -s * .3, -s, 0, -s * .3); c.bezierCurveTo(s * .3, -s, s, -s * .4, 0, s * .3); c.fill(); }
function bgLoop(t) {
  bx.clearRect(0, 0, W, H);
  for (const p of parts) {
    p.y += p.v; p.x += Math.sin(t / 1500 + p.w) * .4; p.r += .01; if (p.y > H + 20) Object.assign(p, mk(-20));
    bx.save(); bx.translate(p.x, p.y); bx.rotate(p.r); bx.globalAlpha = .6;
    if (p.k === "pearl") { const g = bx.createRadialGradient(-p.s / 3, -p.s / 3, 1, 0, 0, p.s / 2); g.addColorStop(0, "#fff"); g.addColorStop(1, "#efb6cc"); bx.fillStyle = g; bx.beginPath(); bx.arc(0, 0, p.s / 2, 0, 7); bx.fill(); }
    else if (p.k === "heart") { bx.fillStyle = "#efb6cc"; drawHeart(bx, p.s); }
    else { bx.fillStyle = "#f4a9c5"; bx.beginPath(); bx.ellipse(0, 0, p.s, p.s / 2, 0, 0, 7); bx.fill(); }
    bx.restore();
  }
  if (!document.hidden) requestAnimationFrame(bgLoop);
}
document.addEventListener("visibilitychange", () => !document.hidden && requestAnimationFrame(bgLoop));

/* ---------------- confetti + fireworks ---------------- */
let fxp = [], fxOn = false;
const COL = ["#efb6cc", "#fce7ef", "#d98aab", "#fff", "#f7c873", "#b0476f"];
function confetti(n = 120, x = W / 2, y = H / 2) { if (reduced) n = 20; for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, v = 4 + Math.random() * 9; fxp.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 5, g: .2, l: 140, c: COL[i % 6], w: 5 + Math.random() * 6, h: 3 + Math.random() * 5, r: Math.random() * 6 }); } run(); }
function firework(x, y) { const c = COL[Math.random() * 6 | 0]; for (let i = 0; i < 60; i++) { const a = i / 60 * 6.28, v = 2 + Math.random() * 4; fxp.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: .05, l: 70, c, w: 3, h: 3, r: 0, glow: 1 }); } blip(200 + Math.random() * 200, .3, .04); run(); }
function run() { if (!fxOn) { fxOn = true; requestAnimationFrame(fxLoop); } }
function fxLoop() {
  fxc.clearRect(0, 0, W, H);
  fxp = fxp.filter(p => p.l-- > 0 && p.y < H + 30);
  for (const p of fxp) { p.vx *= .985; p.vy += p.g; p.x += p.vx; p.y += p.vy; p.r += .2; fxc.globalAlpha = Math.min(1, p.l / 40); fxc.fillStyle = p.c; fxc.save(); fxc.translate(p.x, p.y); fxc.rotate(p.r); fxc.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); fxc.restore(); }
  fxc.globalAlpha = 1;
  fxp.length ? requestAnimationFrame(fxLoop) : (fxOn = false, fxc.clearRect(0, 0, W, H));
}
function fireworksShow(ms = 5000) { const t = setInterval(() => firework(W * (.15 + Math.random() * .7), H * (.12 + Math.random() * .4)), 450); setTimeout(() => clearInterval(t), ms); }

/* ---------------- butterflies ---------------- */
const BF = c => `<svg viewBox="0 0 40 30"><path d="M20 15C14 2 3 0 2 8c-1 8 9 10 18 7zM20 15c6-13 17-15 18-7 1 8-9 10-18 7zM20 15c-8 3-12 12-6 14 4 1 6-6 6-14zM20 15c8 3 12 12 6 14-4 1-6-6-6-14z" fill="${c}"/></svg>`;
function butterflies(n = 8) {
  if (reduced) return;
  for (let i = 0; i < n; i++) {
    const b = el("div", "bf", BF(i % 2 ? "#efb6cc" : "#d98aab")), x = Math.random() * W, y = H * (.4 + Math.random() * .5);
    b.style.cssText = `left:${x}px;top:${y}px`; document.body.append(b);
    b.animate([{ transform: "translate(0,0) rotate(0) scale(.5)", opacity: 0 }, { opacity: 1, offset: .15 }, { transform: `translate(${(Math.random() - .5) * 400}px,${-y - 60}px) rotate(${(Math.random() - .5) * 60}deg) scale(1.1)`, opacity: .9 }], { duration: 5000 + Math.random() * 3000, delay: i * 150, fill: "forwards" }).onfinish = () => b.remove();
  }
}

/* ---------------- scroll reveals ---------------- */
const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && (e.target.classList.add("in"), io.unobserve(e.target))), { threshold: .15 });
const watch = () => $$(".rv:not(.in)").forEach(e => io.observe(e));

/* ---------------- 3D gift ---------------- */
function cube(host, w, h, d, cls = "") {
  host.style.cssText += `width:0;height:0`;
  const faces = [["", w, h, `translateZ(${d / 2}px)`], ["", w, h, `rotateY(180deg) translateZ(${d / 2}px)`], ["", d, h, `rotateY(90deg) translateZ(${w / 2}px)`], ["", d, h, `rotateY(-90deg) translateZ(${w / 2}px)`], ["top", w, d, `rotateX(90deg) translateZ(${h / 2}px)`], ["bot", w, d, `rotateX(-90deg) translateZ(${h / 2}px)`]];
  faces.forEach(([c, fw, fh, t]) => { const f = el("div", "f " + c); f.style.cssText = `width:${fw}px;height:${fh}px;margin:${-fh / 2}px 0 0 ${-fw / 2}px;transform:${t}`; host.append(f); });
}
cube($(".gift .body"), 150, 110, 150); cube($(".gift .lid"), 170, 36, 170);

const intro = $("#intro"), gift = $("#gift");
$("#start").onclick = async () => {
  blip(880); chime(); parts.push(...Array.from({ length: 20 }, () => mk(-10)));
  startMusic();
  intro.style.transition = "opacity .9s,transform .9s"; intro.style.opacity = 0; intro.style.transform = "scale(1.08)";
  await sleep(800); document.body.classList.remove("locked"); intro.classList.add("hidden");
  gift.classList.remove("hidden"); gift.classList.add("enter"); scrollTo(0, 0);
  document.body.classList.add("locked");
};
let giftOpen = false;
$("#giftBtn").onclick = async () => {
  if (giftOpen) return; giftOpen = true; chime(); $("#giftHint").style.opacity = 0;
  $("#giftWrap").classList.add("opened");
  await sleep(700); confetti(180, W / 2, H * .4); butterflies(10);
  $("#hb").innerHTML = "HAPPY BIRTHDAY SAMANA!".split(" ").map((w, i) => `<span class="w">${[...w].map((c, j) => `<span style="animation-delay:${(i * 7 + j) * 70}ms">${c}</span>`).join("")}</span>`).join(" ");
  $("#reveal").classList.remove("hidden"); $("#journey").classList.remove("hidden");
  $("#giftWrap").style.height = "170px"; document.body.classList.remove("locked"); watch();
  setTimeout(() => confetti(100, W * .2, H * .5), 900); setTimeout(() => confetti(100, W * .8, H * .5), 1300);
};
$("#go").onclick = () => { blip(700); $("#memories").scrollIntoView({ behavior: "smooth" }); };

/* ---------------- memories + lightbox ---------------- */
let cur = 0;
function photoNode(p, i) {
  const box = el("div", "ph"), img = new Image(); img.alt = p.caption; img.loading = "lazy"; img.decoding = "async";
  img.onerror = () => { img.remove(); box.textContent = "Add " + p.src.split("/").pop(); };
  img.src = p.src; box.append(img); return box;
}
CONTENT.photos.forEach((p, i) => {
  const b = el("button", "pol rv"); b.style.setProperty("--r", ((i % 2 ? 1 : -1) * (1 + Math.random() * 3)).toFixed(1) + "deg");
  b.setAttribute("aria-label", "Open photo: " + p.caption); b.append(photoNode(p, i), el("p", "", esc(p.caption)));
  b.onclick = () => { cur = i; showLb(); blip(740); }; $("#gallery").append(b);
});
function showLb() {
  const p = CONTENT.photos[cur]; $("#lbImg").replaceChildren(photoNode(p, cur)); $("#lbCap").textContent = p.caption; $("#lb").classList.remove("hidden");
}
const lbGo = d => { cur = (cur + d + CONTENT.photos.length) % CONTENT.photos.length; showLb(); blip(600, .08); };
$("#lb").onclick = e => { const a = e.target.dataset.a; if (a === "close" || e.target.id === "lb") $("#lb").classList.add("hidden"); if (a === "next") lbGo(1); if (a === "prev") lbGo(-1); };
addEventListener("keydown", e => { if ($("#lb").classList.contains("hidden")) return; if (e.key === "Escape") $("#lb").classList.add("hidden"); if (e.key === "ArrowRight") lbGo(1); if (e.key === "ArrowLeft") lbGo(-1); });
let tx; $("#lb").addEventListener("touchstart", e => tx = e.touches[0].clientX, { passive: true });
$("#lb").addEventListener("touchend", e => { const d = e.changedTouches[0].clientX - tx; if (Math.abs(d) > 50) lbGo(d < 0 ? 1 : -1); });

/* ---------------- things only we understand ---------------- */
CONTENT.usCards.forEach((c, i) => { const d = el("article", "card glass rv", `<h3>${esc(c.title)}</h3><p>${esc(c.text)}</p>`); d.style.transitionDelay = i * 90 + "ms"; $("#usCards").append(d); });

/* ---------------- 10 reasons ---------------- */
CONTENT.reasons.slice(0, 10).forEach((r, i) => {
  const b = el("button", "rc rv", `<i class="a">${i + 1}</i><i class="b">${esc(r)}</i>`);
  b.setAttribute("aria-label", "Reason " + (i + 1) + ", tap to reveal"); b.style.transitionDelay = (i % 5) * 70 + "ms";
  b.onclick = () => { b.classList.toggle("on"); blip(500 + i * 60, .2); if (b.classList.contains("on")) sparkle(b); }; $("#reasonCards").append(b);
});
function sparkle(b) { const r = b.getBoundingClientRect(); confetti(14, r.left + r.width / 2, r.top + r.height / 2); }

/* ---------------- letter ---------------- */
let typing = 0;
function fitEnv() { const e = $("#env"); e.style.height = Math.max(420, $(".paper", e).offsetHeight + 10) + "px"; }
$("#env").onclick = async function () {
  if (this.classList.contains("open")) return; this.classList.add("open"); chime();
  const t = $("#letterText"), id = ++typing; await sleep(1500);
  for (const ch of CONTENT.letter) { if (id !== typing) return; t.textContent += ch; if (t.textContent.length % 12 === 0) fitEnv(); if (ch !== " " && Math.random() < .12) hearts(); await sleep(reduced ? 1 : ch === "\n" ? 200 : 38); }
};
function hearts() { const h = el("div", "bf", "♡"); h.style.cssText = `left:${W * (.2 + Math.random() * .6)}px;top:${H * .8}px;font-size:${16 + Math.random() * 18}px;color:#d98aab;width:auto`; document.body.append(h); h.animate([{ opacity: 0 }, { opacity: 1, offset: .2 }, { transform: `translateY(-${H * .5}px)`, opacity: 0 }], { duration: 4000 }).onfinish = () => h.remove(); }

/* ---------------- quiz ---------------- */
let qi = 0, score = 0;
function quiz() {
  const box = $("#quizBox"), Q = CONTENT.quiz;
  if (qi >= Q.length) {
    box.innerHTML = `<p class="script big2">${score}/${Q.length}</p><h3>${esc(CONTENT.quizResults[Math.min(score, CONTENT.quizResults.length - 1)])}</h3><button class="btn" id="qr">Play again</button>`;
    $("#qr").onclick = () => { qi = score = 0; quiz(); }; if (score >= Q.length - 1) confetti(120, W / 2, H / 2); return;
  }
  const q = Q[qi]; box.innerHTML = `<p class="sub">Question ${qi + 1} of ${Q.length}</p><h3>${esc(q.q)}</h3>`;
  q.options.forEach((o, i) => { const b = el("button", "opt", esc(o)); b.onclick = async () => { $$(".opt", box).forEach(x => x.disabled = true); b.classList.add("ok"); if (i === q.answer) { score++; chime(); } else blip(300, .2); await sleep(900); qi++; quiz(); }; box.append(b); });
}

/* ---------------- cake ---------------- */
const cd = $("#candles"); let lit = 0;
for (let i = 0; i < 3; i++) { const c = el("button", "cd"); c.setAttribute("aria-label", "Light candle " + (i + 1)); c.onclick = () => { if (c.classList.contains("lit") || c.classList.contains("out")) return; c.classList.add("lit"); lit++; blip(900 + i * 100, .2); $("#blow").disabled = false; $("#cakeHint").textContent = lit < 3 ? "Light the other candles too, or blow when you are ready." : "Make a wish… then blow them out."; }; cd.append(c); }
$("#blow").onclick = async function () {
  this.disabled = true; $$(".cd.lit").forEach(c => { c.classList.replace("lit", "out"); }); blip(200, .6, .06);
  await sleep(900); confetti(200, W / 2, H * .4); fireworksShow(); butterflies(8);
  $("#cakeTitle").textContent = "Your wish is on its way."; $("#cakeHint").classList.add("hidden"); this.classList.add("hidden");
  $("#finalMsg").textContent = CONTENT.finalMessage; $("#final").classList.remove("hidden"); $("#final").scrollIntoView({ behavior: "smooth", block: "center" });
};

/* ---------------- replay ---------------- */
$("#replay").onclick = async () => {
  blip(880); typing++; document.body.classList.add("locked"); scrollTo({ top: 0, behavior: "smooth" }); await sleep(900);
  giftOpen = false; lit = qi = score = 0; $("#journey").classList.add("hidden"); $("#reveal").classList.add("hidden");
  $("#giftWrap").classList.remove("opened"); $("#giftWrap").style.height = ""; $("#giftHint").style.opacity = 1; gift.classList.add("hidden");
  $("#letterText").textContent = ""; $("#env").classList.remove("open"); $("#env").style.height = ""; $$(".cd").forEach(c => c.className = "cd");
  $("#blow").disabled = true; $("#blow").classList.remove("hidden"); $("#final").classList.add("hidden"); $("#cakeHint").classList.remove("hidden");
  $("#cakeHint").textContent = "Tap each candle to light it."; $("#cakeTitle").textContent = "Make a wish, Samana."; quiz();
  $$(".rc.on").forEach(c => c.classList.remove("on"));
  intro.classList.remove("hidden"); intro.style.opacity = intro.style.transform = ""; $$("#intro>*").forEach(e => { e.style.animation = "none"; e.offsetWidth; e.style.animation = ""; });
  scrollTo(0, 0);
};

/* ---------------- init ---------------- */
size(); addEventListener("resize", size); parts = Array.from({ length: innerWidth < 600 ? 14 : 28 }, () => mk()); requestAnimationFrame(bgLoop);
gift.classList.add("hidden"); quiz(); watch();

/* ---------------- premium extras ---------------- */
function spark(x, y, n = 6) { for (let i = 0; i < n; i++) fxp.push({ x, y, vx: (Math.random() - .5) * 2.4, vy: (Math.random() - .5) * 2.4 - .6, g: .03, l: 38, c: ["#fff", "#efb6cc", "#f7c873"][i % 3], w: 3, h: 3, r: 0 }); run(); }
let lastMove = 0;
addEventListener("pointermove", e => { if (e.pointerType === "mouse" && performance.now() - lastMove > 35) { lastMove = performance.now(); spark(e.clientX, e.clientY, 2); } });
addEventListener("pointerdown", e => { if (!e.target.closest(".lb")) spark(e.clientX, e.clientY, 10); });
addEventListener("scroll", () => { const m = document.documentElement.scrollHeight - innerHeight; $("#prog").style.transform = `scaleX(${m > 0 ? scrollY / m : 0})`; }, { passive: true });
function heartwork(x, y) {
  for (let i = 0; i < 70; i++) { const t = i / 70 * 6.283, hx = 16 * Math.sin(t) ** 3, hy = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)); fxp.push({ x, y, vx: hx * .24, vy: hy * .24, g: .025, l: 95, c: i % 2 ? "#f4a9c5" : "#fff", w: 4, h: 4, r: 0 }); }
  blip(500, .4, .04); run();
}
function fireworksShow(ms = 7000) { let n = 0; const t = setInterval(() => { const x = W * (.15 + Math.random() * .7), y = H * (.12 + Math.random() * .4); n++ % 3 === 1 ? heartwork(x, y) : firework(x, y); }, 550); setTimeout(() => clearInterval(t), ms); }
function shooting(n = 8) { if (reduced) return; for (let i = 0; i < n; i++) { const s = el("div", "ss"); s.style.cssText = `left:${10 + Math.random() * 80}%;top:${Math.random() * 30}%`; $("#cake").append(s); s.animate([{ transform: "translate(0,0) rotate(35deg)", opacity: 1 }, { transform: "translate(-340px,230px) rotate(35deg)", opacity: 0 }], { duration: 1400, delay: i * 450, fill: "both" }).onfinish = () => s.remove(); } }
$("#blow").addEventListener("click", () => setTimeout(() => shooting(8), 900));
for (let i = 0; i < 40; i++) { const s = el("span", "st"); s.style.cssText = `left:${Math.random() * 100}%;top:${Math.random() * 100}%;animation-delay:${Math.random() * 3}s;transform:scale(${.5 + Math.random()})`; $("#cake").append(s); }
$("#giftBtn").addEventListener("click", () => { setTimeout(() => { const f = el("div", "flash"); document.body.append(f); setTimeout(() => f.remove(), 1000); }, 700); navigator.vibrate && navigator.vibrate([30, 40, 30]); });
$("#wishBtn").onclick = () => {
  const v = $("#wish").value.trim(); if (!v) return $("#wish").focus();
  const w = el("div", "wishfly", esc(v)); document.body.append(w);
  w.animate([{ transform: "translate(-50%,0)", opacity: 1 }, { transform: `translate(-50%,-${H * .75}px) scale(.6)`, opacity: 0 }], { duration: 5000 }).onfinish = () => w.remove();
  window.open("https://wa.me/" + CONTENT.whatsapp + "?text=" + encodeURIComponent("Samana's birthday wish: " + v), "_blank", "noopener");
  $("#wish").value = ""; heartwork(W / 2, H * .3); chime();
};
